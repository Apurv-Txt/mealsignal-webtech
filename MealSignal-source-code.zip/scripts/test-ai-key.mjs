// Checks the configured OpenAI-compatible key without logging it.
import { existsSync, readFileSync } from "node:fs";
if (existsSync(".env.local")) for (const line of readFileSync(".env.local", "utf8").split(/\r?\n/)) { const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/); if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, ""); }
if (!process.env.AI_API_KEY) { console.error("AI_API_KEY is missing. Add it to .env.local."); process.exit(1); }
const base = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
try {
  const response = await fetch(`${base}/chat/completions`, { method: "POST", headers: { Authorization: `Bearer ${process.env.AI_API_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ model: process.env.AI_MODEL || "gpt-4o-mini", max_tokens: 5, messages: [{ role: "user", content: "Reply OK" }] }) });
  if (response.ok) console.log("AI key and model connection: OK");
  else { const reason = response.status === 401 ? "wrong key" : response.status === 404 ? "wrong model or base URL" : response.status === 429 ? "rate limit" : `HTTP ${response.status}`; console.error(`AI connection failed: ${reason}.`); process.exit(1); }
} catch { console.error("AI connection failed: network error."); process.exit(1); }
