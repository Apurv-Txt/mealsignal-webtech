# MealSignal — Web Technologies Project Report

**Team:** (Student 1 name), (Student 2 name)  
**Course:** Web Technologies  
**GitHub:** (add repository URL after publishing)  
**Live demo:** (add Vercel URL after deployment)

## 1. Overview

MealSignal is a full-stack web application for hostel messes, tiffin providers and small caterers. It connects meal planning, diner reservations, anonymous dish ratings and post-service portion records. Providers can inspect trends and request feedback insights; diners can view meals, reserve or skip, and rate served dishes.

## 2. Objectives

- Keep meal schedules, diner signals and portion outcomes together.
- Give providers a simple record of prepared, served and leftover portions.
- Let diners reserve and rate without exposing their account identity to providers.
- Use recent same-service history for a transparent demand estimate.
- Add optional server-side AI summaries with a local fallback.

## 3. Technologies

| Area | Technology |
|---|---|
| Frontend | Next.js 16 App Router, React 19, TypeScript |
| Backend | Next.js Route Handlers |
| Authentication | Supabase Auth |
| Database | PostgreSQL through Supabase |
| Access control | Row Level Security policies |
| Optional AI | OpenAI-compatible chat-completions API |
| Forecast | Historical same-service walk-in average and backtest |

## 4. Implemented features

1. Provider and diner sign-up/sign-in with workspace roles.
2. Meal planning with service type, date/time, dishes and expected portions.
3. Diner menu with separate reserve/skip status per meal.
4. Post-service per-dish ratings and comments, editable by the diner.
5. Provider service log with prepared/served/leftover validation.
6. Provider dashboard with meal, rating, leftover and reservation-coverage summaries.
7. Anonymous feedback page with search, rating filters and CSV export.
8. 7/14/30-day analytics and simulated-data filtering.
9. On-demand AI feedback themes with locally generated fallback.
10. Demand estimate with a same-service historical baseline and MAE/MAPE comparison.
11. Provider simulator that creates clearly marked sample service history.

**Live-data note:** These workflows require the SQL migrations and Supabase environment variables to be configured. The AI summary requires an additional API key for LLM mode; Local mode needs no AI key. The database migration and live flows still need to be run and verified in the team's Supabase project before claiming live integration.

## 5. Screenshots

Capture real screenshots after setting up Supabase and sample data. Replace each placeholder below with a screenshot from the submitted build.

| Screen | Screenshot |
|---|---|
| Sign-in and role sign-up | (capture `public/report/login.png`) |
| Diner menu and reservation | (capture `public/report/diner-menu.png`) |
| Diner rating | (capture `public/report/diner-rating.png`) |
| Provider dashboard and service log | (capture `public/report/dashboard.png`) |
| Meal planning | (capture `public/report/meals.png`) |
| Anonymous feedback and insights | (capture `public/report/feedback.png`) |
| Analytics and forecast backtest | (capture `public/report/analytics.png`) |
| Mobile view | (capture `public/report/mobile.png`) |

## 6. System design

```mermaid
flowchart LR
  D[Diner browser] --> N[Next.js app]
  P[Provider browser] --> N
  N --> A[Supabase Auth]
  N --> R[Next.js API routes]
  N --> DB[(Supabase PostgreSQL + RLS)]
  R --> DB
  R --> L[Optional LLM API]
```

The browser uses Supabase Auth and the public client key. Row Level Security scopes rows by the signed-in user's organization and role. Protected Next.js routes verify the bearer token before reading provider data or calling an LLM. The AI key remains in server environment variables.

## 7. Database tables

- `organizations`: provider workspace name and diner join code.
- `profiles`: signed-in user role, display name and organization.
- `meals`: service time, type, dishes and expected/actual portions.
- `reservations`: reserve/skip state; simulator entries are marked.
- `feedback`: dish rating and optional comment; provider reads do not expose diner account IDs.
- `meal_stats`: aggregate ratings and reservation counts without account identifiers.

## 8. Security and privacy

The v2 SQL migration adds role-aware policies, private diner reservation/rating reads, and simulated-row support. Provider feedback queries do not select diner IDs, and the migration revokes table-level client reads before granting safe columns. API routes verify the caller and provider role. The AI route reads comments from the provider's database scope rather than trusting comments sent by the browser. Review and execute the SQL migration in Supabase before representing these policies as active in the deployed app.

## 9. Verification

| Check | Expected result | Result |
|---|---|---|
| TypeScript compile (`npx tsc --noEmit`) | No type errors | Passed in the local project environment |
| Production build | App compiles and route generation completes | Pending rerun after removing external font download |
| Provider/diner authentication | Accounts enter their correct workspace | Pending live Supabase setup |
| Reservation and feedback privacy | Diner sees only own rows; provider sees anonymous feedback | Pending migration execution and account-level check |
| Simulator and analytics | Sample records appear and can be cleared | Pending live Supabase check |
| AI local/LLM modes | Local fallback works; valid key returns AI summary | Pending live key/API check |

No automated test suite is included. The manual checks above should be completed before submission.

## 10. Division of work

The planned ownership split is 60/40 and should be updated to match the work the students actually perform and can explain. No student names or completed human contributions are assumed here.

| Member | Planned ownership | Share | Suggested demo features |
|---|---|---:|---|
| Member 1: (name) | Frontend, authentication, database/RLS, meal planning, reservations, service logging and analytics | 60% | Meal planning; diner reservation and rating flow |
| Member 2: (name) | AI and forecast implementation in `app/api/insights/`, `app/api/forecast/`, `lib/ai/` and `components/ai/` | 40% | Evidence-backed feedback insights; demand forecast and backtest |

AI assistance was used to draft and revise the implementation and documentation. The students should run the app, verify the database behavior, understand their assigned modules, and record the work each actually completes.

## 11. Limitations and future work

- Live functionality depends on manual Supabase migration and environment setup.
- The demand estimate is a simple explainable baseline; it is not a trained prediction model.
- LLM themes can be imperfect and should be checked against the source comments.
- The UI uses a hand-built responsive CSS theme rather than a component framework.
- Future work could add location-based demand, ingredient costs and controlled evaluation of forecast quality.
