# MealSignal

MealSignal helps hostel messes, tiffin providers and small caterers plan meal portions. Diners can reserve or skip a meal and rate dishes after service. Providers record what was prepared, served and left over, then review anonymous feedback, service analytics, a demand estimate and optional AI insights.

## Features

- Provider and diner sign-up with separate workspaces
- Meal planning with date, service type, dishes and expected portions
- Diner menu, individual reservations and skips
- Anonymous dish ratings after a meal is served
- Provider service log with portion validation
- Dashboard and date-filtered service analytics
- Demand forecast with an historical error comparison
- On-demand feedback summary using an LLM or a local keyword fallback
- Explicit sample-data simulator; generated records are marked simulated

The pages show records from Supabase only. A fresh database uses empty states until a provider creates meals or loads the sample history.

## Technology

- Next.js 16 App Router, React 19 and TypeScript
- Supabase Auth and PostgreSQL
- Row Level Security for provider and diner access
- Next.js Route Handlers for protected AI analysis, forecast, simulator and export operations
- OpenAI-compatible chat-completions API for optional feedback insights

## Requirements

- Node.js 20.9 or later
- npm
- A modern browser
- Supabase project for sign-in and saved data
- Optional OpenAI-compatible API key for AI-generated insights

## Run locally

In PowerShell:

```powershell
cd "C:\Users\APURV\Desktop\3rd Year\WebTech\PROJECT"
npm install
npm run dev
```

Open `http://localhost:3000` and sign in. Keep PowerShell open while the app is running. Press **Ctrl+C** to stop the server.

The project needs Supabase configuration to sign in. Copy `.env.example` to `.env.local` and fill the Supabase values before using the app.

## Supabase setup

1. Create a Supabase project and open its **SQL Editor**.
2. Run `supabase/migrations/202610170001_initial_schema.sql`.
3. Run `supabase/migrations/202610180001_v2.sql`.
4. In the project settings, copy the Project URL and anon/public key into `.env.local`:

   ```text
   NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_KEY
   ```

5. Start MealSignal and create a provider account at `/login`. For a classroom demo, either disable email confirmation under Supabase Auth settings or confirm the signup email.
6. In SQL Editor, run `supabase/seed.sql` to load a simulated 14-day menu for the first provider organization. Alternatively, sign in as that provider and use **Simulator → Simulate last 14 days**.
7. Share the provider join code from the Dashboard with a diner, then create a diner account using that code.

The v2 migration removes client access to feedback and reservation account IDs. Providers see anonymous organization feedback; diners can read only their own reservations and ratings. AI and forecasting API routes verify the bearer token and provider role.

## Environment variables

| Name | Required for | Secret? |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase data and auth | No |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase browser client | No, protected by RLS |
| `AI_API_KEY` | LLM feedback summaries | Yes, server only |
| `AI_MODEL` | Optional model override | No |
| `AI_BASE_URL` | Optional compatible API base URL | No |

Never commit `.env.local` or put the AI key in a `NEXT_PUBLIC_` variable. Check configuration without printing values using `npm run check:env`. To make a small connection call to the configured LLM, run `npm run test:ai-key`. Without an AI key, insights use local keyword grouping.

## Demo flow

1. Create a provider account and plan a meal.
2. Share the diner join code and create a diner account.
3. Reserve or skip an upcoming meal from the diner Menu.
4. As the provider, log portions prepared, served and left over from Dashboard.
5. As a diner, rate dishes after the meal is marked Served.
6. Review anonymous comments and export filtered feedback as CSV.
7. Generate feedback insights. With no LLM key, the badge reports Local mode.
8. Use the provider Simulator to generate labeled history, then inspect analytics and forecast error.

## Deploying to Vercel

1. Install the Vercel CLI with `npm install -g vercel` and sign in using `vercel login`.
2. From this project folder run `vercel` and follow the prompts to create a project. For a production deployment, run `vercel --prod`.
3. In Vercel project settings, add `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, and optionally `AI_API_KEY`, `AI_MODEL`, and `AI_BASE_URL` for Production and Preview as needed. Redeploy after changing environment values.
4. In Supabase **Authentication → URL Configuration**, set the Site URL to the deployed Vercel URL. Add `https://YOUR-APP.vercel.app/**` to the allowed redirect URLs. Keep `http://localhost:3000/**` in the list for development.
5. Open the deployed app and confirm provider and diner sign-in, database access, and API routes.

This repo has not been deployed. Add the live URL after completing those steps.

## Project structure

```text
app/                    Routes and protected API handlers
components/             Role-aware shell and feature pages
components/ai/          Forecast and insight displays
lib/                    Supabase client, constants and API helpers
lib/ai/                 Local AI fallback
supabase/migrations/    Database schema and RLS policies
supabase/seed.sql       Optional sample menu history
```

## Source and submission

- GitHub repository: https://github.com/Apurv-Txt/mealsignal-webtech
- Evidence screenshots for the dashboard, meals, feedback and analytics are stored separately in `public/report/` and embedded in the course report. Analytics includes simulated demo records; feedback insights used Local mode because no AI API key was configured.
- Report: the completed submission copy is `MealSignal_WT_Project_Report_Final.docx` in the project folder; the report is provided separately from the source archive.
- Viva notes: see `EXPLAIN.md`.




