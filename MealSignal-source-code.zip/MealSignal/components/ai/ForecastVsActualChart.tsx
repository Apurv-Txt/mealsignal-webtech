// Displays historical forecast error and the previous-service baseline.
"use client";
import { useEffect, useState } from "react";
import { apiFetch } from "../../lib/api";
import { Card, EmptyState } from "../ui";

type Result = { series: { date: string; forecast: number; actual: number; baseline: number | null }[]; mae: number | null; mape: number | null; baselineMae: number | null };
export function ForecastVsActualChart() {
  const [result, setResult] = useState<Result | null>(null);
  useEffect(() => { void apiFetch("/api/forecast/backtest?days=30").then(response => response.json()).then(setResult); }, []);
  return <Card><h2>Forecast vs actual</h2>{!result ? <p className="muted">Loading forecast history…</p> : result.series.length === 0 ? <EmptyState>Log a few services to compare forecast accuracy.</EmptyState> : <><div className="metric-grid compact-grid"><p>MAE <strong>{result.mae}</strong></p><p>MAPE <strong>{result.mape}%</strong></p><p>Previous-service MAE <strong>{result.baselineMae}</strong></p></div><div className="chart-list">{result.series.slice(-10).map((row, index) => <div className="chart-row" key={`${row.date}-${index}`}><span>{new Date(row.date).toLocaleDateString()}</span><div className="chart-track"><i style={{ width: `${Math.min(100, row.forecast)}%` }} /><b style={{ width: `${Math.min(100, row.actual)}%` }} /></div><span>{row.forecast}/{row.actual}</span></div>)}</div></>}</Card>;
}
