# MealSignal — plain-English project walkthrough

## What the app does

MealSignal connects a meal provider with diners. The provider publishes what will be served and how many portions are expected. Diners reserve or skip each meal. After service, a diner can rate individual dishes. The provider records the actual portions prepared, served and left over. Those records are used in the dashboard, analytics and a simple demand estimate.

## How to start it

1. Copy `.env.example` to `.env.local` and add the Supabase project URL and public key.
2. Run both SQL migration files in order in Supabase SQL Editor.
3. In PowerShell, run `npm install`, then `npm run dev` inside the project folder.
4. Open `http://localhost:3000` and create a provider account.
5. Use the provider's diner code to create a diner account.
6. Optional: load `supabase/seed.sql` or use the Simulator page to create sample history.

## Main folders and files

- `app/`: URL pages and server API routes. For example, `app/meals/page.tsx` opens the meal-planning screen.
- `components/`: visible pages and navigation shared by providers and diners.
- `components/ai/`: cards that display feedback insights and demand estimates.
- `lib/supabase.ts`: one reusable browser connection to Supabase.
- `lib/api.ts`: adds the signed-in access token to protected API requests.
- `lib/server-auth.ts`: checks that token on the server and loads the user's role.
- `lib/constants.ts`: one home for fixed choices such as meal types and rating options.
- `lib/ai/`: fallback feedback grouping that works without an AI key.
- `supabase/migrations/`: database tables, access policies and aggregate view.
- `supabase/seed.sql`: optional sample menu history for a provider organization.

## Feature flow

1. **Sign-up:** Supabase Auth stores the account. A database trigger creates its profile and either creates a provider organization or joins one using a code.
2. **Meal planning:** providers create, edit and delete meals. Dish names and service times are saved in PostgreSQL.
3. **Reservations:** diners reserve or skip each meal separately. Row Level Security limits diner queries to that diner's rows.
4. **Ratings:** after a service is marked Served, diners save a rating and optional comment for a dish. Provider feedback queries do not return account identifiers.
5. **Service log:** providers enter portions prepared, served and left. The UI rejects negative values and counts where served plus leftovers exceed prepared.
6. **Insights:** the provider clicks Generate insights. The server reads recent comments from the provider's organization. It uses an LLM if a key is configured; otherwise it groups a few common words locally.
7. **Forecast:** the server reads current reservations and the previous served meals of the same service type. It estimates walk-ins and compares historical estimates to actual service counts.
8. **Simulator:** the provider can create explicitly marked sample meals, reservations and ratings for a presentation, then clear them later.

## Viva notes

### Member 1 — meal planning and diner workflow

Explain how the provider form writes a meal to Supabase, then how the diner sees meals from the same organization. Point out that each reservation is stored against one meal, so changing one meal does not change another. Describe how Row Level Security checks the account role and organization. Demonstrate dish rating after service.

### Member 2 — AI insights and demand forecast

Explain that the AI route verifies the signed-in provider, reads comments from the database, and keeps the AI key on the server. It checks the returned evidence against source comments and falls back to local keyword grouping without a key. For the forecast, show how current reservations are added to the recent average of walk-ins for the same service type, then describe MAE and MAPE from the backtest.

### Be ready to explain the limitations

The forecast is a transparent baseline, not a machine-learning model. AI text may be imperfect, so its quoted evidence and suggestions need human review. Live database behavior must be demonstrated after the migrations are applied to the team's Supabase project.
