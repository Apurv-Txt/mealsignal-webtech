-- MealSignal initial schema. Run in the Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  join_code text not null unique default upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 8)),
  created_at timestamptz not null default now()
);
create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  organization_id uuid references public.organizations(id) on delete set null,
  display_name text not null default 'MealSignal user',
  role text not null check (role in ('provider', 'diner')),
  created_at timestamptz not null default now()
);
create table if not exists public.meals (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  meal_name text not null,
  service_type text not null check (service_type in ('Breakfast', 'Lunch', 'Dinner', 'Tiffin')),
  service_at timestamptz not null,
  dishes text[] not null default '{}',
  expected_portions integer not null default 0 check (expected_portions >= 0),
  prepared_portions integer not null default 0 check (prepared_portions >= 0),
  served_portions integer not null default 0 check (served_portions >= 0),
  leftover_portions integer not null default 0 check (leftover_portions >= 0),
  rating_avg numeric(2,1) not null default 0 check (rating_avg between 0 and 5),
  status text not null default 'Planning' check (status in ('Planning', 'Upcoming', 'Served')),
  created_at timestamptz not null default now()
);
create table if not exists public.reservations (
  id uuid primary key default gen_random_uuid(),
  meal_id uuid not null references public.meals(id) on delete cascade,
  diner_id uuid not null references public.profiles(user_id) on delete cascade,
  status text not null check (status in ('reserved', 'skipped')),
  created_at timestamptz not null default now(),
  unique (meal_id, diner_id)
);
create table if not exists public.feedback (
  id uuid primary key default gen_random_uuid(),
  meal_id uuid not null references public.meals(id) on delete cascade,
  diner_id uuid not null references public.profiles(user_id) on delete cascade,
  dish text not null,
  rating integer not null check (rating between 1 and 5),
  comment text not null default '' check (char_length(comment) <= 600),
  created_at timestamptz not null default now(),
  unique (meal_id, diner_id, dish)
);

create index if not exists meals_org_service_idx on public.meals (organization_id, service_at desc);
create index if not exists reservations_meal_idx on public.reservations (meal_id, status);
create index if not exists feedback_meal_idx on public.feedback (meal_id, created_at desc);

-- Create an organization for providers, or join an existing organization with its diner code.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare org_id uuid; account_role text; org_name text; code text;
begin
  account_role := coalesce(new.raw_user_meta_data->>'account_role', 'diner');
  if account_role = 'provider' then
    org_name := coalesce(nullif(new.raw_user_meta_data->>'organization_name', ''), 'My Meal Service');
    insert into public.organizations(name) values (org_name) returning id into org_id;
  else
    code := upper(coalesce(new.raw_user_meta_data->>'join_code', ''));
    select id into org_id from public.organizations where join_code = code;
    if org_id is null then raise exception 'That provider join code was not found.'; end if;
    account_role := 'diner';
  end if;
  insert into public.profiles(user_id, organization_id, display_name, role)
  values (new.id, org_id, coalesce(nullif(new.raw_user_meta_data->>'display_name', ''), split_part(new.email, '@', 1)), account_role);
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.my_org_id() returns uuid language sql stable security definer set search_path = public as $$
  select organization_id from public.profiles where user_id = auth.uid()
$$;
create or replace function public.is_provider() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where user_id = auth.uid() and role = 'provider')
$$;
create or replace function public.is_diner() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where user_id = auth.uid() and role = 'diner')
$$;

alter table public.organizations enable row level security;
alter table public.profiles enable row level security;
alter table public.meals enable row level security;
alter table public.reservations enable row level security;
alter table public.feedback enable row level security;

create policy "members read own organization" on public.organizations for select using (id = public.my_org_id());
create policy "members read organization profiles" on public.profiles for select using (organization_id = public.my_org_id());
create policy "users read own profile" on public.profiles for select using (user_id = auth.uid());
create policy "members read organization meals" on public.meals for select using (organization_id = public.my_org_id());
create policy "providers create meals" on public.meals for insert with check (organization_id = public.my_org_id() and public.is_provider());
create policy "providers update meals" on public.meals for update using (organization_id = public.my_org_id() and public.is_provider()) with check (organization_id = public.my_org_id() and public.is_provider());
create policy "providers delete meals" on public.meals for delete using (organization_id = public.my_org_id() and public.is_provider());
create policy "members read meal reservations" on public.reservations for select using (exists (select 1 from public.meals m where m.id = meal_id and m.organization_id = public.my_org_id()));
create policy "diners manage own reservation" on public.reservations for insert with check (diner_id = auth.uid() and public.is_diner() and exists (select 1 from public.meals m where m.id = meal_id and m.organization_id = public.my_org_id()));
create policy "diners update own reservation" on public.reservations for update using (diner_id = auth.uid() and public.is_diner()) with check (diner_id = auth.uid() and public.is_diner());
create policy "members read feedback in organization" on public.feedback for select using (exists (select 1 from public.meals m where m.id = meal_id and m.organization_id = public.my_org_id()));
create policy "diners submit own feedback" on public.feedback for insert with check (diner_id = auth.uid() and public.is_diner() and exists (select 1 from public.meals m where m.id = meal_id and m.organization_id = public.my_org_id()));
create policy "diners edit own feedback" on public.feedback for update using (diner_id = auth.uid() and public.is_diner()) with check (diner_id = auth.uid() and public.is_diner());

grant usage on schema public to authenticated;
grant select on public.organizations, public.profiles, public.meals, public.reservations, public.feedback to authenticated;
grant insert, update, delete on public.meals to authenticated;
-- Profiles are created through the auth trigger; clients cannot change roles or workspace membership.
grant insert, update on public.reservations, public.feedback to authenticated;
