-- MealSignal v2: anonymous feedback, safe aggregates and simulator support.
create or replace function public.check_join_code(requested_code text)
returns text language sql stable security definer set search_path = public as $$
  select name from public.organizations where join_code = upper(trim(requested_code)) limit 1;
$$;
grant execute on function public.check_join_code(text) to anon, authenticated;

alter table public.reservations alter column diner_id drop not null;
alter table public.feedback alter column diner_id drop not null;
alter table public.reservations add column if not exists simulated boolean not null default false;
alter table public.feedback add column if not exists simulated boolean not null default false;
alter table public.meals add column if not exists simulated boolean not null default false;
alter table public.reservations drop constraint if exists reservations_simulated_diner_check;
alter table public.feedback drop constraint if exists feedback_simulated_diner_check;
alter table public.reservations add constraint reservations_simulated_diner_check check (diner_id is not null or simulated);
alter table public.feedback add constraint feedback_simulated_diner_check check (diner_id is not null or simulated);

drop policy if exists "members read organization profiles" on public.profiles;
drop policy if exists "providers read organization profiles" on public.profiles;
drop policy if exists "members read meal reservations" on public.reservations;
drop policy if exists "diners manage own reservation" on public.reservations;
drop policy if exists "diners update own reservation" on public.reservations;
drop policy if exists "members read feedback in organization" on public.feedback;
drop policy if exists "diners submit own feedback" on public.feedback;
drop policy if exists "diners edit own feedback" on public.feedback;
drop policy if exists "diners read own reservation" on public.reservations;
drop policy if exists "providers read organization reservations" on public.reservations;
drop policy if exists "diners reserve own organization meals" on public.reservations;
drop policy if exists "diners update own future reservation" on public.reservations;
drop policy if exists "providers add simulated reservations" on public.reservations;
drop policy if exists "providers delete simulated reservations" on public.reservations;
drop policy if exists "providers read organization feedback" on public.feedback;
drop policy if exists "diners read own feedback" on public.feedback;
drop policy if exists "diners submit feedback after service" on public.feedback;
drop policy if exists "diners update own feedback" on public.feedback;
drop policy if exists "providers add simulated feedback" on public.feedback;
drop policy if exists "providers delete simulated feedback" on public.feedback;

create policy "diners read own reservation" on public.reservations for select using (diner_id = auth.uid());
create policy "providers read organization reservations" on public.reservations for select using (public.is_provider() and exists (select 1 from public.meals m where m.id = meal_id and m.organization_id = public.my_org_id()));
create policy "diners reserve own organization meals" on public.reservations for insert with check (diner_id = auth.uid() and public.is_diner() and exists (select 1 from public.meals m where m.id = meal_id and m.organization_id = public.my_org_id() and m.service_at > now()));
create policy "diners update own future reservation" on public.reservations for update using (diner_id = auth.uid() and exists (select 1 from public.meals m where m.id = meal_id and m.service_at > now())) with check (diner_id = auth.uid() and public.is_diner());
create policy "providers add simulated reservations" on public.reservations for insert with check (simulated and diner_id is null and public.is_provider() and exists (select 1 from public.meals m where m.id = meal_id and m.organization_id = public.my_org_id()));
create policy "providers delete simulated reservations" on public.reservations for delete using (simulated and public.is_provider() and exists (select 1 from public.meals m where m.id = meal_id and m.organization_id = public.my_org_id()));

create policy "providers read organization feedback" on public.feedback for select using (public.is_provider() and exists (select 1 from public.meals m where m.id = meal_id and m.organization_id = public.my_org_id()));
create policy "diners read own feedback" on public.feedback for select using (diner_id = auth.uid());
create policy "diners submit feedback after service" on public.feedback for insert with check (diner_id = auth.uid() and public.is_diner() and exists (select 1 from public.meals m where m.id = meal_id and m.organization_id = public.my_org_id() and m.status = 'Served'));
create policy "diners update own feedback" on public.feedback for update using (diner_id = auth.uid() and exists (select 1 from public.meals m where m.id = meal_id and m.status = 'Served')) with check (diner_id = auth.uid());
create policy "providers add simulated feedback" on public.feedback for insert with check (simulated and diner_id is null and public.is_provider() and exists (select 1 from public.meals m where m.id = meal_id and m.organization_id = public.my_org_id()));
create policy "providers delete simulated feedback" on public.feedback for delete using (simulated and public.is_provider() and exists (select 1 from public.meals m where m.id = meal_id and m.organization_id = public.my_org_id()));
drop policy if exists "providers delete simulated meals" on public.meals;
create policy "providers delete simulated meals" on public.meals for delete using (simulated and public.is_provider() and organization_id = public.my_org_id());

-- No account identifier is readable by any client, including providers.
revoke select on public.feedback, public.reservations from anon, authenticated;
grant select (id, meal_id, dish, rating, comment, created_at, simulated) on public.feedback to authenticated;
grant select (id, meal_id, status, created_at, simulated) on public.reservations to authenticated;
grant insert (meal_id, diner_id, status, simulated), update (status), delete on public.reservations to authenticated;
grant insert (meal_id, diner_id, dish, rating, comment, simulated), update (rating, comment), delete on public.feedback to authenticated;

drop view if exists public.meal_stats;
-- This view exposes aggregate values only; the org filter remains tied to auth.uid().
create view public.meal_stats as
select m.id as meal_id, coalesce(round(avg(f.rating)::numeric, 1), 0) as avg_rating,
  count(distinct f.id) as rating_count,
  count(distinct r.id) filter (where r.status = 'reserved') as reserved_count,
  count(distinct r.id) filter (where r.status = 'skipped') as skipped_count
from public.meals m left join public.feedback f on f.meal_id = m.id
left join public.reservations r on r.meal_id = m.id
where m.organization_id = public.my_org_id() group by m.id;
grant select on public.meal_stats to authenticated;

grant delete on public.reservations, public.feedback to authenticated;
