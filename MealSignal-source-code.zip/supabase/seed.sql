-- Adds a small upcoming and past menu to the first provider workspace.
insert into public.meals (organization_id, meal_name, service_type, service_at, dishes, expected_portions, prepared_portions, served_portions, leftover_portions, status, simulated)
select org.id,
  case slot.kind when 'Breakfast' then 'Breakfast service' when 'Lunch' then 'Lunch service' when 'Dinner' then 'Dinner service' else 'Tiffin delivery' end,
  slot.kind,
  (current_date + day.day_offset + slot.service_time)::timestamptz,
  case slot.kind when 'Breakfast' then array['Idli', 'Sambar', 'Fruit'] when 'Lunch' then array['Rice', 'Dal', 'Seasonal vegetables'] when 'Dinner' then array['Roti', 'Paneer curry', 'Salad'] else array['Tiffin meal', 'Fruit'] end,
  80, case when day.day_offset < 0 then 80 else 0 end,
  case when day.day_offset < 0 then 70 + ((abs(day.day_offset) * 7) % 15) else 0 end,
  case when day.day_offset < 0 then 80 - (70 + ((abs(day.day_offset) * 7) % 15)) else 0 end,
  case when day.day_offset < 0 then 'Served' else 'Upcoming' end, true
from (select id from public.organizations order by created_at limit 1) org
cross join generate_series(-14, 7) as day(day_offset)
cross join lateral (values
  ('Breakfast', time '08:00'), ('Lunch', time '12:30'), ('Dinner', time '19:30')
) as slot(kind, service_time)
where not exists (select 1 from public.meals existing where existing.organization_id = org.id and existing.service_at = (current_date + day.day_offset + slot.service_time)::timestamptz);
