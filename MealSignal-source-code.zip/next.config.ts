// Uses a single build worker for reliable builds on classroom laptops.
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: { cpus: 1 },
};

export default nextConfig;
