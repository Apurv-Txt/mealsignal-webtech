// Provides a simple local feedback summary when an LLM key is unavailable.
type Feedback = { dish: string; comment: string; rating: number };
import { AI_THEME_LIMIT, AI_ACTION_LIMIT, AI_EVIDENCE_LIMIT } from "../constants";
const groups = [
  { label: "Temperature", words: ["cold", "warm", "hot", "temperature"] },
  { label: "Portions", words: ["portion", "small", "large", "enough"] },
  { label: "Taste", words: ["taste", "spicy", "bland", "salty", "seasoning"] },
  { label: "Freshness", words: ["fresh", "stale", "crisp", "spoiled"] },
];
export function localInsights(rows: Feedback[]) {
  const themes = groups.map(group => {
    const matches = rows.filter(row => group.words.some(word => row.comment.toLowerCase().includes(word)));
    return { label: group.label, count: matches.length, evidence: matches.slice(0, 2).map(row => row.comment.slice(0, 160)) };
  }).filter(theme => theme.count > 0).sort((a, b) => b.count - a.count).slice(0, AI_THEME_LIMIT).map(theme => ({ ...theme, evidence: theme.evidence.slice(0, AI_EVIDENCE_LIMIT) }));
  return { headline: themes.length ? `The clearest recent signal is ${themes[0].label.toLowerCase()}.` : "Not enough repeated feedback themes yet.", themes, actions: themes.slice(0, AI_ACTION_LIMIT).map(theme => `Review ${theme.label.toLowerCase()} across the next service.`), sourceCount: rows.length, mode: "Local" };
}
