// Verifies API callers with Supabase Auth and returns their role-scoped client.
import { createClient } from "@supabase/supabase-js";

export async function getCaller(request: Request) {
  const token = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!token || !url || !key) return null;
  const db = createClient(url, key, { global: { headers: { Authorization: `Bearer ${token}` } }, auth: { persistSession: false } });
  const { data: { user }, error } = await db.auth.getUser(token);
  if (error || !user) return null;
  const { data: profile } = await db.from("profiles").select("role,organization_id,display_name").eq("user_id", user.id).single();
  if (!profile?.organization_id || !profile.role) return null;
  return { db, user, profile };
}
