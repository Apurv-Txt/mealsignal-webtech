// Adds the signed-in Supabase token to calls to our protected API routes.
import { getSupabase } from "./supabase";

export async function apiFetch(path: string, options: RequestInit = {}) {
  const session = await getSupabase()?.auth.getSession();
  const token = session?.data.session?.access_token;
  const headers = new Headers(options.headers);
  if (token) headers.set("Authorization", `Bearer ${token}`);
  if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  return fetch(path, { ...options, headers });
}
