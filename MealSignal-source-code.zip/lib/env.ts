// Reads environment settings without exposing secret values.
export function getAiSettings() {
  return {
    key: process.env.AI_API_KEY || "",
    model: process.env.AI_MODEL || "gpt-4o-mini",
    baseUrl: (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, ""),
  };
}

export function checkEnvironment() {
  return {
    NEXT_PUBLIC_SUPABASE_URL: Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL),
    NEXT_PUBLIC_SUPABASE_ANON_KEY: Boolean(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY),
    AI_API_KEY: Boolean(process.env.AI_API_KEY),
    AI_MODEL: Boolean(process.env.AI_MODEL),
    AI_BASE_URL: Boolean(process.env.AI_BASE_URL),
  };
}
