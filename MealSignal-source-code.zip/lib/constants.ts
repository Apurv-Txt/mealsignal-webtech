// Shared choices and limits used by the MealSignal screens.
export const SERVICE_TYPES = ["Breakfast", "Lunch", "Dinner", "Tiffin"] as const;
export const PAGE_SIZE = 50;
export const MAX_COMMENT_LENGTH = 600;
export const INSIGHT_FEEDBACK_LIMIT = 100;
export const INSIGHT_COMMENT_LENGTH = 200;
export const FORECAST_HISTORY_LIMIT = 5;
export const FORECAST_BACKTEST_MAX_DAYS = 30;
export const FORECAST_MIN_CONFIDENCE_SERVICES = 3;
export const SIMULATED_HISTORY_DAYS = 14;
export const SIMULATED_PORTIONS = 80;
export const SIMULATED_RESERVATION_RATE = 0.7;
export const SIMULATED_FEEDBACK_PER_MEAL = 4;
export const ANALYTICS_RANGES = [7, 14, 30] as const;
export const DASHBOARD_SUMMARY_DAYS = 7;
export const DINER_MENU_PAST_DAYS = 14;
export const DINER_MENU_FUTURE_DAYS = 7;
export const FEEDBACK_EXPORT_LIMIT = 1000;
export const AI_THEME_LIMIT = 3;
export const AI_ACTION_LIMIT = 3;
export const AI_EVIDENCE_LIMIT = 2;
export const RATING_OPTIONS = [1, 2, 3, 4, 5] as const;
export const NAV_ITEMS = {
  provider: ["Dashboard", "Meals", "Feedback", "Analytics", "Simulator"],
  diner: ["Menu", "My reservations", "My ratings"],
} as const;
