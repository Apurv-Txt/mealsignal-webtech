// Shows anonymous feedback with basic filters and server-side insights.
"use client";

import { useEffect, useMemo, useState } from "react";
import { AppShell } from "./AppShell";
import { InsightsPanel } from "./ai/InsightsPanel";
import { Button, Card, EmptyState, Input } from "./ui";
import { getSupabase } from "../lib/supabase";
import { PAGE_SIZE } from "../lib/constants";
import { apiFetch } from "../lib/api";

type Feedback = {
  id: string;
  dish: string;
  comment: string;
  rating: number;
  created_at: string;
  simulated?: boolean;
};

export function FeedbackPage() {
  const [rows, setRows] = useState<Feedback[]>([]);
  const [search, setSearch] = useState("");
  const [rating, setRating] = useState("All");
  const [limit, setLimit] = useState(PAGE_SIZE);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    void getSupabase()?.from("feedback")
      .select("id,dish,comment,rating,created_at,simulated")
      .order("created_at", { ascending: false })
      .then(({ data, error: issue }) => {
        setRows(data || []);
        setError(issue?.message || "");
        setLoading(false);
      });
  }, []);

  const filtered = useMemo(() => rows.filter(row => {
    const matchesRating = rating === "All" || row.rating === Number(rating);
    const text = `${row.dish} ${row.comment}`.toLowerCase();
    return matchesRating && text.includes(search.toLowerCase());
  }), [rows, rating, search]);

  const average = filtered.length
    ? (filtered.reduce((sum, row) => sum + row.rating, 0) / filtered.length).toFixed(1)
    : "—";

  async function exportCsv() {
    const params = new URLSearchParams({ search, rating });
    const response = await apiFetch(`/api/export/feedback?${params}`);
    if (!response.ok) { setError("Could not export feedback."); return; }
    const fileUrl = URL.createObjectURL(await response.blob());
    const link = document.createElement("a");
    link.href = fileUrl;
    link.download = "mealsignal-feedback.csv";
    link.click();
    URL.revokeObjectURL(fileUrl);
  }

  return <AppShell role="provider">
    <div className="page">
      <div className="page-heading">
        <p className="eyebrow">DINER SIGNALS</p>
        <h1>Feedback</h1>
        <p className="muted">Comments are shown without diner names or account IDs.</p>
      </div>
      <InsightsPanel />
      <Card>
        <div className="inline-heading">
          <div><h2>{filtered.length} ratings · {average} average</h2><p className="muted">Based on the current filter</p></div>
          <Button className="button-secondary" onClick={() => void exportCsv()}>Export filtered CSV</Button>
        </div>
        <div className="filter-row">
          <Input aria-label="Search feedback" placeholder="Search dish or comment" value={search} onChange={event => setSearch(event.target.value)} />
          <select aria-label="Filter by rating" className="input" value={rating} onChange={event => setRating(event.target.value)}>
            <option>All</option>{[5, 4, 3, 2, 1].map(value => <option key={value} value={value}>{value} stars</option>)}
          </select>
        </div>
        {error && <p className="error-text">{error}</p>}
        {loading ? <EmptyState>Loading feedback…</EmptyState> : filtered.length === 0 ? <EmptyState>No feedback matches these filters.</EmptyState> : <div className="stack">
          {filtered.slice(0, limit).map(row => <article key={row.id} className="feedback-row">
            <div className="meal-row"><strong>{row.dish}</strong><span aria-label={`${row.rating} out of 5`}>{"★".repeat(row.rating)}{"☆".repeat(5 - row.rating)} · {row.rating}/5</span></div>
            <p>{row.comment || "No comment provided."}</p>
            <small className="muted">{new Date(row.created_at).toLocaleString()}{row.simulated ? " · Simulated" : ""}</small>
          </article>)}
        </div>}
        {filtered.length > limit && <Button className="button-secondary" onClick={() => setLimit(limit + PAGE_SIZE)}>Load more</Button>}
      </Card>
    </div>
  </AppShell>;
}
