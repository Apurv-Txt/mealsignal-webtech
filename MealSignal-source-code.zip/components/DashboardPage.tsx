// Shows provider metrics and records meal service results from Supabase.
"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { AppShell } from "./AppShell";
import { ForecastCard } from "./ai/ForecastCard";
import { Badge, Button, Card, EmptyState, Input } from "./ui";
import { useUser } from "./useUser";
import { getSupabase } from "../lib/supabase";
import { DASHBOARD_SUMMARY_DAYS } from "../lib/constants";

type Meal = {
  id: string;
  meal_name: string;
  service_at: string;
  status: string;
  expected_portions: number;
  served_portions: number;
  prepared_portions: number;
  leftover_portions: number;
};
type Reservation = { meal_id: string; status: string };

export function DashboardPage() {
  const { profile } = useUser();
  const [meals, setMeals] = useState<Meal[]>([]);
  const [weekMeals, setWeekMeals] = useState<Meal[]>([]);
  const [ratings, setRatings] = useState<number[]>([]);
  const [reserved, setReserved] = useState(0);
  const [workspace, setWorkspace] = useState("");
  const [joinCode, setJoinCode] = useState("");
  const [message, setMessage] = useState("");
  const [busyId, setBusyId] = useState("");

  useEffect(() => {
    if (!profile) return;
    const db = getSupabase();
    if (!db) return;
    const today = new Date();
    const start = new Date(today);
    start.setHours(0, 0, 0, 0);
    const end = new Date(start);
    end.setDate(end.getDate() + 1);
    const week = new Date(Date.now() - DASHBOARD_SUMMARY_DAYS * 86400000).toISOString();
    const columns = "id,meal_name,service_at,status,expected_portions,served_portions,prepared_portions,leftover_portions";
    void Promise.all([
      db.from("meals").select(columns).gte("service_at", start.toISOString()).lt("service_at", end.toISOString()).order("service_at"),
      db.from("meals").select(columns).gte("service_at", week).lte("service_at", new Date().toISOString()),
      db.from("feedback").select("rating").gte("created_at", week),
      db.from("organizations").select("name,join_code").eq("id", profile.organization_id).single(),
    ]).then(async ([todayResult, weekResult, feedbackResult, organizationResult]) => {
      const weekRows = weekResult.data || [];
      const ids = weekRows.map(row => row.id);
      const reservationResult = ids.length
        ? await db.from("reservations").select("meal_id,status").in("meal_id", ids).eq("status", "reserved")
        : { data: [] as Reservation[] };
      setMeals(todayResult.data || []);
      setWeekMeals(weekRows);
      setRatings((feedbackResult.data || []).map(row => row.rating));
      setReserved(reservationResult.data?.length || 0);
      setWorkspace(organizationResult.data?.name || "");
      setJoinCode(organizationResult.data?.join_code || "");
    });
  }, [profile]);

  async function saveLog(event: React.FormEvent<HTMLFormElement>, meal: Meal) {
    event.preventDefault();
    setMessage("");
    setBusyId(meal.id);
    const fields = new FormData(event.currentTarget);
    const prepared = Number(fields.get("prepared"));
    const served = Number(fields.get("served"));
    const leftover = Number(fields.get("leftover"));
    const invalid = [prepared, served, leftover].some(value => !Number.isInteger(value) || value < 0);
    if (invalid || served + leftover > prepared) {
      setMessage("Use whole numbers. Served plus leftovers cannot exceed prepared.");
      setBusyId("");
      return;
    }
    const result = await getSupabase()!.from("meals").update({
      prepared_portions: prepared,
      served_portions: served,
      leftover_portions: leftover,
      status: "Served",
    }).eq("id", meal.id);
    if (result.error) setMessage(result.error.message);
    else setMeals(rows => rows.map(row => row.id === meal.id
      ? { ...row, prepared_portions: prepared, served_portions: served, leftover_portions: leftover, status: "Served" }
      : row));
    setBusyId("");
  }

  async function copyCode() {
    await navigator.clipboard.writeText(joinCode);
    setMessage("Diner join code copied.");
  }

  const expected = meals.reduce((sum, meal) => sum + meal.expected_portions, 0);
  const prepared = weekMeals.reduce((sum, meal) => sum + meal.prepared_portions, 0);
  const leftovers = weekMeals.reduce((sum, meal) => sum + meal.leftover_portions, 0);
  const weekExpected = weekMeals.reduce((sum, meal) => sum + meal.expected_portions, 0);
  const average = ratings.length ? (ratings.reduce((sum, rating) => sum + rating, 0) / ratings.length).toFixed(1) : "—";
  const nextMeal = meals.find(meal => meal.status !== "Served");

  return <AppShell role="provider">
    <div className="page">
      <div className="page-heading">
        <p className="eyebrow">PROVIDER WORKSPACE</p>
        <h1>Dashboard</h1>
        <p className="muted">{workspace || "Your meal service"} · Today’s service at a glance.</p>
      </div>
      <div className="metric-grid">
        <Card><span className="muted">Meals today</span><strong className="metric-value">{meals.length}</strong></Card>
        <Card><span className="muted">Average rating · 7 days</span><strong className="metric-value">{average}</strong></Card>
        <Card><span className="muted">Leftover rate · 7 days</span><strong className="metric-value">{prepared ? `${Math.round(leftovers / prepared * 100)}%` : "—"}</strong></Card>
        <Card><span className="muted">Reservation coverage · 7 days</span><strong className="metric-value">{weekExpected ? `${Math.round(reserved / weekExpected * 100)}%` : "—"}</strong></Card>
      </div>
      <div className="inline-heading">
        <div><h2>Today’s service</h2><p className="muted">{expected} expected portions · record what was prepared and served.</p></div>
        {joinCode && <Button className="button-secondary" onClick={() => void copyCode()}>Copy diner code · {joinCode}</Button>}
      </div>
      {message && <p role="status" className="notice">{message}</p>}
      {meals.length === 0 ? <Card><EmptyState>No meals scheduled today. <Link href="/meals">Plan a meal</Link>.</EmptyState></Card> : <div className="stack">
        {meals.map(meal => <Card key={meal.id}>
          <div className="meal-row"><div><h3>{meal.meal_name}</h3><p className="muted">{new Date(meal.service_at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })} · {meal.expected_portions} expected</p></div><Badge>{meal.status}</Badge></div>
          {meal.status !== "Served" && <form className="log-form" onSubmit={event => void saveLog(event, meal)}>
            {["prepared", "served", "leftover"].map(label => <label key={label}>{label === "leftover" ? "Left over" : label[0].toUpperCase() + label.slice(1)}<Input name={label} type="number" min="0" step="1" required defaultValue="0" /></label>)}
            <Button disabled={busyId === meal.id}>{busyId === meal.id ? "Saving…" : "Save service"}</Button>
          </form>}
        </Card>)}
      </div>}
      {nextMeal && <ForecastCard mealId={nextMeal.id} />}
    </div>
  </AppShell>;
}
