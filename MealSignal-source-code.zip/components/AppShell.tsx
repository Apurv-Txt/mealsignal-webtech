// Provides role-aware navigation and a compact mobile tab bar.
"use client";

import { useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Activity, CalendarDays, ChartNoAxesCombined, FlaskConical, LogOut, MessageSquare, Utensils, Users } from "lucide-react";
import { NAV_ITEMS } from "../lib/constants";
import { getSupabase } from "../lib/supabase";
import { useUser } from "./useUser";

const destinations: Record<string, string> = {
  Dashboard: "/dashboard",
  Meals: "/meals",
  Feedback: "/feedback",
  Analytics: "/analytics",
  Simulator: "/simulator",
  Menu: "/diner",
  "My reservations": "/diner#my-reservations",
  "My ratings": "/diner#my-ratings",
};
const icons = [Activity, CalendarDays, MessageSquare, ChartNoAxesCombined, FlaskConical, Utensils, Users];

export function AppShell({ children, role }: { children: React.ReactNode; role?: "provider" | "diner" }) {
  const { user, profile, loading } = useUser();
  const pathname = usePathname();
  const router = useRouter();
  const actualRole = role || profile?.role || "provider";
  const names = actualRole === "provider" ? NAV_ITEMS.provider : NAV_ITEMS.diner;

  useEffect(() => {
    if (!loading && !user && pathname !== "/login") router.replace("/login");
  }, [loading, user, pathname, router]);

  if (loading) return <main className="center-page">Loading MealSignal…</main>;
  if (!user) return <main className="center-page">Please sign in to view this workspace.</main>;
  if (!profile) return <main className="center-page">Your profile is unavailable. Check that the Supabase migration ran successfully.</main>;
  if (role && profile.role !== role) {
    const home = profile.role === "diner" ? "/diner" : "/dashboard";
    return <main className="center-page">This page is for {role}s. <Link href={home}>Go to your workspace</Link></main>;
  }

  async function signOut() {
    await getSupabase()?.auth.signOut();
    router.push("/login");
  }

  function navigationLink(name: string, index: number, mobile = false) {
    const Icon = icons[index];
    const destination = destinations[name];
    const currentPath = destination.split("#")[0];
    const selected = pathname === currentPath;
    const className = mobile ? (selected ? "active" : "") : `nav-link ${selected ? "active" : ""}`;
    return <Link key={name} href={destination} aria-label={mobile ? name : undefined} className={className}>
      <Icon size={mobile ? 19 : 18}/>{mobile ? <span>{name}</span> : name}
    </Link>;
  }

  return <div className="shell">
    <aside className="sidebar">
      <Link href={actualRole === "diner" ? "/diner" : "/dashboard"} className="brand">
        <span className="brand-mark"><Activity size={20}/></span>MealSignal
      </Link>
      <p className="nav-label">WORKSPACE</p>
      <nav>{names.map((name, index) => navigationLink(name, index))}</nav>
      <div className="side-bottom">
        <div className="user-summary">
          <span className="avatar">{(profile.display_name || user.email || "M").slice(0, 1).toUpperCase()}</span>
          <span>{profile.display_name || user.email}<small>{actualRole}</small></span>
        </div>
        <button className="logout" onClick={() => void signOut()}><LogOut size={16}/> Sign out</button>
      </div>
    </aside>
    <main className="main-content">
      <header className="mobile-header">
        <Link href={actualRole === "diner" ? "/diner" : "/dashboard"} className="brand">
          <span className="brand-mark"><Activity size={20}/></span>MealSignal
        </Link>
      </header>
      {children}
    </main>
    <nav className="mobile-nav" style={{ gridTemplateColumns: `repeat(${names.length}, minmax(0, 1fr))` }}>
      {names.map((name, index) => navigationLink(name, index, true))}
    </nav>
  </div>;
}
