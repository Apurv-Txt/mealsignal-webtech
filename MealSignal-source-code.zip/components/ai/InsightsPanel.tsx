// Displays an evidence-backed feedback summary generated on request.
"use client";
import { useState } from "react";
import { apiFetch } from "../../lib/api";
import { Button, Card, EmptyState } from "../ui";

type Summary = { headline: string; themes: { label: string; count: number; evidence: string[] }[]; actions: string[]; sourceCount: number; mode: string };
export function InsightsPanel() {
  const [summary, setSummary] = useState<Summary | null>(null); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function generate() { setBusy(true); setError(""); try { const response = await apiFetch("/api/insights", { method: "POST" }); const result = await response.json(); if (!response.ok) throw new Error(result.error || "Could not generate insights."); setSummary(result); } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not generate insights."); } finally { setBusy(false); } }
  return <Card><div className="meal-row"><div><h2>Feedback insights</h2><p className="muted">Generate a short summary from recent anonymous comments.</p></div><Button onClick={() => void generate()} disabled={busy}>{busy ? "Analyzing…" : "Generate insights"}</Button></div>{error && <p className="error-text">{error}</p>}{!summary ? <EmptyState>Insights run only when you request them.</EmptyState> : <div className="stack"><p>{summary.headline}</p><p className="muted">{summary.sourceCount} comments · {summary.mode} mode</p>{summary.themes.map((theme, themeIndex) => <div key={`${theme.label}-${themeIndex}`} className="theme"><strong>{theme.label}</strong> <span className="muted">{theme.count} mentions</span>{theme.evidence.map((quote, quoteIndex) => <blockquote key={`${themeIndex}-${quoteIndex}`}>“{quote}”</blockquote>)}</div>)}{summary.actions.map((action, index) => <p key={`${action}-${index}`}>Suggested action: {action}</p>)}</div>}</Card>;
}
