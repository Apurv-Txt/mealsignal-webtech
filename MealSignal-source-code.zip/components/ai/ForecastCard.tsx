// Shows a server-calculated forecast for an upcoming meal.
"use client";
import { useState } from "react";
import { apiFetch } from "../../lib/api";
import { Button, Card } from "../ui";

type Forecast = { total: number; low: number; high: number; reservations: number; confidence: string; explanation: string };
export function ForecastCard({ mealId }: { mealId: string }) {
  const [result, setResult] = useState<Forecast | null>(null); const [error, setError] = useState(""); const [busy, setBusy] = useState(false); const [buffer, setBuffer] = useState(5);
  async function load() { setBusy(true); setError(""); const response = await apiFetch(`/api/forecast?mealId=${encodeURIComponent(mealId)}`); const data = await response.json(); if (response.ok) setResult(data); else setError(data.error); setBusy(false); }
  return <Card className="forecast-card"><div className="meal-row"><strong>Demand estimate</strong><Button className="button-secondary" disabled={busy} onClick={() => void load()}>{busy ? "Calculating…" : "Calculate"}</Button></div>{error && <p className="error-text">{error}</p>}{result && <><p className="forecast-number">{result.total}<small> portions</small></p><p>{result.low}–{result.high} expected · {result.confidence}</p><p className="muted">{result.explanation}</p><label>Prep buffer (%) <input className="input compact-input" type="number" min="0" max="30" value={buffer} onChange={e => setBuffer(Number(e.target.value))}/></label><p>Suggested prep: <strong>{Math.ceil(result.total * (1 + buffer / 100))}</strong></p></>}</Card>;
}
