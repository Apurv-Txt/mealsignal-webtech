// Lets providers add, edit, filter and delete meals stored in Supabase.
"use client";

import { useEffect, useState } from "react";
import { AppShell } from "./AppShell";
import { Badge, Button, Card, EmptyState, Input } from "./ui";
import { useUser } from "./useUser";
import { getSupabase } from "../lib/supabase";
import { SERVICE_TYPES } from "../lib/constants";

type Meal = {
  id: string;
  meal_name: string;
  service_type: string;
  service_at: string;
  dishes: string[];
  expected_portions: number;
  status: string;
};
type MealForm = {
  meal_name: string;
  service_type: string;
  service_at: string;
  dishes: string;
  expected_portions: string;
};
const emptyForm: MealForm = {
  meal_name: "",
  service_type: "Lunch",
  service_at: "",
  dishes: "",
  expected_portions: "",
};
const mealColumns = "id,meal_name,service_type,service_at,dishes,expected_portions,status";

export function MealsPage() {
  const { profile } = useUser();
  const [meals, setMeals] = useState<Meal[]>([]);
  const [form, setForm] = useState<MealForm>(emptyForm);
  const [editing, setEditing] = useState("");
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("Upcoming");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const db = getSupabase();
    if (!db) { setLoading(false); return; }
    void db.from("meals").select(mealColumns).order("service_at").then(({ data, error: issue }) => {
      setMeals(data || []);
      setError(issue?.message || "");
      setLoading(false);
    });
  }, [profile]);

  function change(field: keyof MealForm, value: string) {
    setForm(current => ({ ...current, [field]: value }));
  }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    const serviceDate = new Date(form.service_at);
    const dishes = form.dishes.split(",").map(item => item.trim()).filter(Boolean);
    const portions = Number(form.expected_portions);
    if (!Number.isFinite(serviceDate.getTime())) { setError("Choose a valid date and time."); return; }
    if (!dishes.length) { setError("Add at least one dish, separated by commas."); return; }
    if (!Number.isInteger(portions) || portions < 0) { setError("Expected portions must be a whole number."); return; }

    const values = {
      meal_name: form.meal_name.trim(),
      service_type: form.service_type,
      service_at: serviceDate.toISOString(),
      dishes,
      expected_portions: portions,
    };
    const db = getSupabase()!;
    const result = editing
      ? await db.from("meals").update(values).eq("id", editing).select(mealColumns).single()
      : await db.from("meals").insert({ ...values, organization_id: profile?.organization_id, status: "Upcoming" }).select(mealColumns).single();
    if (result.error) { setError(result.error.message); return; }
    if (!result.data) { setError("The meal was not returned. Refresh and try again."); return; }
    setMeals(rows => editing
      ? rows.map(row => row.id === editing ? result.data : row)
      : [...rows, result.data].sort((a, b) => a.service_at.localeCompare(b.service_at)));
    setEditing("");
    setForm(emptyForm);
  }

  function edit(meal: Meal) {
    const date = new Date(meal.service_at);
    const localDate = new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    setForm({
      meal_name: meal.meal_name,
      service_type: meal.service_type,
      service_at: localDate,
      dishes: meal.dishes.join(", "),
      expected_portions: String(meal.expected_portions),
    });
    setEditing(meal.id);
  }

  async function remove(meal: Meal) {
    if (!window.confirm(`Delete ${meal.meal_name}?`)) return;
    const { error: issue } = await getSupabase()!.from("meals").delete().eq("id", meal.id);
    if (issue) setError(issue.message);
    else setMeals(rows => rows.filter(row => row.id !== meal.id));
  }

  const now = Date.now();
  const visible = meals.filter(meal => filter === "Upcoming"
    ? new Date(meal.service_at).getTime() >= now
    : new Date(meal.service_at).getTime() < now);

  return <AppShell role="provider">
    <div className="page">
      <div className="page-heading">
        <p className="eyebrow">SERVICE PLAN</p>
        <h1>Meals</h1>
        <p className="muted">Plan the menu and expected portions for each service.</p>
      </div>
      <Card>
        <h2>{editing ? "Edit meal" : "Plan a meal"}</h2>
        <form className="form-grid" onSubmit={event => void save(event)}>
          <label>Meal name<Input required value={form.meal_name} onChange={event => change("meal_name", event.target.value)} /></label>
          <label>Service type<select className="input" value={form.service_type} onChange={event => change("service_type", event.target.value)}>{SERVICE_TYPES.map(type => <option key={type}>{type}</option>)}</select></label>
          <label>Date and time<Input required type="datetime-local" value={form.service_at} onChange={event => change("service_at", event.target.value)} /></label>
          <label>Expected portions<Input required type="number" min="0" step="1" value={form.expected_portions} onChange={event => change("expected_portions", event.target.value)} /></label>
          <label className="wide">Dishes <span className="muted">(comma separated)</span><Input required value={form.dishes} onChange={event => change("dishes", event.target.value)} placeholder="Rice, dal, vegetables" /></label>
          <div className="wide actions">
            <Button>{editing ? "Save changes" : "Add meal"}</Button>
            {editing && <Button type="button" className="button-secondary" onClick={() => { setEditing(""); setForm(emptyForm); }}>Cancel</Button>}
          </div>
        </form>
        {error && <p className="error-text">{error}</p>}
      </Card>
      <div className="inline-heading">
        <h2>Planned meals</h2>
        <select aria-label="Filter meals" className="input filter-select" value={filter} onChange={event => setFilter(event.target.value)}><option>Upcoming</option><option>Past</option></select>
      </div>
      {loading ? <Card><EmptyState>Loading meals…</EmptyState></Card> : visible.length === 0 ? <Card><EmptyState>No {filter.toLowerCase()} meals.</EmptyState></Card> : <div className="stack">
        {visible.map(meal => <Card key={meal.id}>
          <div className="meal-row">
            <div><h3>{meal.meal_name}</h3><p className="muted">{meal.service_type} · {new Date(meal.service_at).toLocaleString()}</p><p>{meal.dishes.join(" · ")}</p><p className="muted">{meal.expected_portions} expected portions</p></div>
            <div className="actions"><Badge>{meal.status}</Badge><Button className="button-secondary" onClick={() => edit(meal)}>Edit</Button><Button className="button-danger" onClick={() => void remove(meal)}>Delete</Button></div>
          </div>
        </Card>)}
      </div>}
    </div>
  </AppShell>;
}
