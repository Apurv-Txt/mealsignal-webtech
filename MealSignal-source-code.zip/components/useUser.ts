// Loads the signed-in user and their organization profile once on the client.
"use client";
import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { getSupabase } from "../lib/supabase";

type Profile = { role: "provider" | "diner"; organization_id: string; display_name: string };
export function useUser() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const db = getSupabase();
    if (!db) { setLoading(false); return; }
    let active = true;
    async function load(nextUser: User | null) {
      setUser(nextUser);
      if (!nextUser) { setProfile(null); setLoading(false); return; }
      const { data } = await db!.from("profiles").select("role,organization_id,display_name").eq("user_id", nextUser.id).single();
      if (active) { setProfile(data); setLoading(false); }
    }
    void db.auth.getSession().then(({ data }) => load(data.session?.user || null));
    const { data: { subscription } } = db.auth.onAuthStateChange((_event, session) => { void load(session?.user || null); });
    return () => { active = false; subscription.unsubscribe(); };
  }, []);
  return { user, profile, loading };
}
