// Handles Supabase email sign-in and provider or diner registration.
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { getSupabase } from "../lib/supabase";
import { Button, Card, Input } from "./ui";

export function LoginForm() {
  const [signup, setSignup] = useState(false);
  const [role, setRole] = useState("provider");
  const [name, setName] = useState("");
  const [organization, setOrganization] = useState("");
  const [code, setCode] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setBusy(true);
    const db = getSupabase();
    if (!db) { setError("Connect Supabase first. Follow Environment setup in README.md."); setBusy(false); return; }
    if (password.length < 8) { setError("Password must be at least 8 characters."); setBusy(false); return; }

    if (signup && role === "diner") {
      const result = await db.rpc("check_join_code", { requested_code: code.toUpperCase() });
      if (result.error || !result.data) {
        setError("That diner code was not found. Check it with your provider.");
        setBusy(false);
        return;
      }
    }

    const result = signup
      ? await db.auth.signUp({ email, password, options: { data: { display_name: name, account_role: role, organization_name: organization, join_code: code.toUpperCase() } } })
      : await db.auth.signInWithPassword({ email, password });
    if (result.error) { setError(result.error.message); setBusy(false); return; }
    if (signup && !result.data.session) {
      setError("Check your email to confirm the account, then sign in.");
      setSignup(false);
      setBusy(false);
      return;
    }

    const userId = result.data.user?.id;
    const { data: profile } = await db.from("profiles").select("role").eq("user_id", userId).single();
    router.push(profile?.role === "diner" ? "/diner" : "/dashboard");
  }

  function toggleMode() {
    setSignup(current => !current);
    setError("");
  }

  return <main className="login-page">
    <div className="login-intro">
      <a className="brand" href="/"><span className="brand-mark">M</span>MealSignal</a>
      <div>
        <p className="eyebrow">MEALS, WITH A CLEARER SIGNAL</p>
        <h1>Make each service a little better.</h1>
        <p>Plan portions with diners’ reservations and feedback in one simple workspace.</p>
      </div>
    </div>
    <Card className="login-card">
      <p className="eyebrow">YOUR WORKSPACE</p>
      <h2>{signup ? "Create an account" : "Welcome back"}</h2>
      <p className="muted">{signup ? "Choose how you use MealSignal." : "Sign in to continue."}</p>
      <form className="form-stack" onSubmit={event => void submit(event)}>
        {signup && <>
          <label>Name<Input required value={name} onChange={event => setName(event.target.value)} /></label>
          <label>Account type<select className="input" value={role} onChange={event => setRole(event.target.value)}>
            <option value="provider">I run a meal service</option><option value="diner">I am a diner</option>
          </select></label>
          {role === "provider"
            ? <label>Service name<Input required value={organization} onChange={event => setOrganization(event.target.value)} /></label>
            : <label>Provider join code<Input required value={code} onChange={event => setCode(event.target.value)} /></label>}
        </>}
        <label>Email<Input type="email" autoComplete="email" required value={email} onChange={event => setEmail(event.target.value)} /></label>
        <label>Password<Input type="password" minLength={8} autoComplete={signup ? "new-password" : "current-password"} required value={password} onChange={event => setPassword(event.target.value)} /></label>
        {error && <p role="alert" className="error-text">{error}</p>}
        <Button disabled={busy}>{busy ? "Please wait…" : signup ? "Create account" : "Sign in"}</Button>
      </form>
      <p className="form-switch">{signup ? "Already registered?" : "New to MealSignal?"} <button onClick={toggleMode}>{signup ? "Sign in" : "Create an account"}</button></p>
    </Card>
  </main>;
}
