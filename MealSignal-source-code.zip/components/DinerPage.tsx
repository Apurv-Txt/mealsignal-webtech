// Gives diners a menu, individual reservations and dish ratings.
"use client";

import { useEffect, useState } from "react";
import { AppShell } from "./AppShell";
import { Badge, Button, Card, EmptyState, Input } from "./ui";
import { getSupabase } from "../lib/supabase";
import { useUser } from "./useUser";
import { DINER_MENU_FUTURE_DAYS, DINER_MENU_PAST_DAYS, MAX_COMMENT_LENGTH, RATING_OPTIONS } from "../lib/constants";

type Meal = { id: string; meal_name: string; service_type: string; service_at: string; dishes: string[]; status: string };
type Reservation = { id: string; meal_id: string; status: string };
type Rating = { id: string; meal_id: string; dish: string; rating: number; comment: string; created_at: string };

export function DinerPage() {
  const { user, profile } = useUser();
  const [meals, setMeals] = useState<Meal[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [ratings, setRatings] = useState<Rating[]>([]);
  const [ratingMeal, setRatingMeal] = useState<Meal | null>(null);
  const [dish, setDish] = useState("");
  const [score, setScore] = useState(5);
  const [comment, setComment] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile || !user) return;
    const db = getSupabase();
    if (!db) return;
    const from = new Date(Date.now() - DINER_MENU_PAST_DAYS * 86400000).toISOString();
    const to = new Date(Date.now() + DINER_MENU_FUTURE_DAYS * 86400000).toISOString();
    void Promise.all([
      db.from("meals").select("id,meal_name,service_type,service_at,dishes,status").eq("organization_id", profile.organization_id).gte("service_at", from).lte("service_at", to).order("service_at"),
      db.from("reservations").select("id,meal_id,status"),
      db.from("feedback").select("id,meal_id,dish,rating,comment,created_at").order("created_at", { ascending: false }),
    ]).then(([mealResult, reservationResult, ratingResult]) => {
      setMeals(mealResult.data || []);
      setReservations(reservationResult.data || []);
      setRatings(ratingResult.data || []);
      setLoading(false);
    });
  }, [profile, user]);

  async function changeReservation(meal: Meal) {
    const old = reservations.find(row => row.meal_id === meal.id);
    const next = old?.status === "reserved" ? "skipped" : "reserved";
    const db = getSupabase()!;
    const result = old
      ? await db.from("reservations").update({ status: next }).eq("id", old.id)
      : await db.from("reservations").insert({ meal_id: meal.id, diner_id: user!.id, status: next }).select("id").single();
    if (result.error) { setMessage(result.error.message); return; }
    if (old) {
      setReservations(rows => rows.map(row => row.id === old.id ? { ...row, status: next } : row));
      return;
    }
    if (!result.data) { setMessage("The reservation was not returned. Refresh and try again."); return; }
    setReservations(rows => [...rows, { id: result.data.id, meal_id: meal.id, status: next }]);
  }

  function openRating(meal: Meal) {
    const firstDish = meal.dishes[0] || meal.meal_name;
    const old = ratings.find(row => row.meal_id === meal.id && row.dish === firstDish);
    setRatingMeal(meal);
    setDish(firstDish);
    setScore(old?.rating || 5);
    setComment(old?.comment || "");
  }

  function selectDish(value: string) {
    setDish(value);
    const old = ratings.find(row => row.meal_id === ratingMeal?.id && row.dish === value);
    setScore(old?.rating || 5);
    setComment(old?.comment || "");
  }

  async function saveRating(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!ratingMeal) return;
    const old = ratings.find(row => row.meal_id === ratingMeal.id && row.dish === dish);
    const db = getSupabase()!;
    const result = old
      ? await db.from("feedback").update({ rating: score, comment }).eq("id", old.id)
      : await db.from("feedback").insert({ meal_id: ratingMeal.id, diner_id: user!.id, dish, rating: score, comment }).select("id,created_at").single();
    if (result.error) { setMessage(result.error.message); return; }
    if (old) {
      setRatings(rows => rows.map(row => row.id === old.id ? { ...row, rating: score, comment } : row));
    } else if (result.data) {
      setRatings(rows => [{ id: result.data.id, meal_id: ratingMeal.id, dish, rating: score, comment, created_at: result.data.created_at }, ...rows]);
    }
    setMessage("Your rating was saved anonymously.");
    setRatingMeal(null);
  }

  return <AppShell role="diner">
    <div className="page">
      <div className="page-heading">
        <p className="eyebrow">DINER PORTAL</p>
        <h1>Menu</h1>
        <p className="muted">Reserve upcoming meals. Ratings unlock after service.</p>
      </div>
      {message && <p role="status" className="notice">{message}</p>}
      {loading ? <Card><EmptyState>Loading your provider’s menu…</EmptyState></Card> : meals.length === 0 ? <Card><EmptyState>Your provider has no meals in this date range yet.</EmptyState></Card> : <div className="stack">
        {meals.map(meal => {
          const reservation = reservations.find(row => row.meal_id === meal.id);
          const closed = new Date(meal.service_at) <= new Date();
          return <Card key={meal.id}>
            <div className="meal-row">
              <div><Badge>{meal.service_type}</Badge><h3>{meal.meal_name}</h3><p className="muted">{new Date(meal.service_at).toLocaleString()}</p><p>{meal.dishes.join(" · ")}</p></div>
              <div className="actions">
                {closed ? <span className="muted">Reservations closed</span> : <Button className={reservation ? "button-secondary" : ""} onClick={() => void changeReservation(meal)}>{reservation?.status === "reserved" ? "Reserved · skip" : reservation?.status === "skipped" ? "Skipped · reserve" : "Reserve"}</Button>}
                {meal.status === "Served" && <Button className="button-secondary" onClick={() => openRating(meal)}>Rate dishes</Button>}
              </div>
            </div>
          </Card>;
        })}
      </div>}
      <section id="my-reservations"><h2>My reservations</h2>{reservations.length === 0 ? <Card><EmptyState>You have not reserved any meals yet.</EmptyState></Card> : <div className="stack">{reservations.map(row => { const meal = meals.find(item => item.id === row.meal_id); if (!meal) return null; return <Card key={row.id}><div className="meal-row"><div><h3>{meal.meal_name}</h3><p className="muted">{new Date(meal.service_at).toLocaleString()}</p></div><Badge>{row.status}</Badge></div></Card>; })}</div>}</section>
      <section id="my-ratings"><h2>My ratings</h2>{ratings.length === 0 ? <Card><EmptyState>Your ratings appear here after you review a served meal.</EmptyState></Card> : <div className="stack">{ratings.map(row => <Card key={row.id}><div className="meal-row"><strong>{row.dish}</strong><Badge>{row.rating}/5</Badge></div><p>{row.comment || "No comment"}</p><small className="muted">{new Date(row.created_at).toLocaleDateString()}</small></Card>)}</div>}</section>
      {ratingMeal && <Card className="rating-card">
        <div className="meal-row"><h2>Rate {ratingMeal.meal_name}</h2><button className="plain-button" onClick={() => setRatingMeal(null)}>Close</button></div>
        <form className="form-stack" onSubmit={event => void saveRating(event)}>
          <label>Dish<select className="input" value={dish} onChange={event => selectDish(event.target.value)}>{ratingMeal.dishes.map(item => <option key={item}>{item}</option>)}</select></label>
          <label>Rating<select className="input" value={score} onChange={event => setScore(Number(event.target.value))}>{RATING_OPTIONS.map(number => <option key={number} value={number}>{number} / 5</option>)}</select></label>
          <label>Comment (optional)<Input value={comment} maxLength={MAX_COMMENT_LENGTH} onChange={event => setComment(event.target.value)} /></label>
          <Button>Save rating</Button>
        </form>
      </Card>}
    </div>
  </AppShell>;
}
