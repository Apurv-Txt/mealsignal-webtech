// Displays service, leftover and rating totals from the selected time range.
"use client";
import { useEffect, useState } from "react";
import { AppShell } from "./AppShell";
import { Card, EmptyState } from "./ui";
import { getSupabase } from "../lib/supabase";
import { ForecastVsActualChart } from "./ai/ForecastVsActualChart";
import { ANALYTICS_RANGES } from "../lib/constants";

type Meal = { id: string; meal_name: string; service_at: string; prepared_portions: number; served_portions: number; leftover_portions: number; simulated: boolean };
type Feedback = { rating: number; simulated: boolean };
export function AnalyticsPage() {
  const [range, setRange] = useState("7"); const [includeSimulated, setIncludeSimulated] = useState(true); const [meals, setMeals] = useState<Meal[]>([]); const [feedback, setFeedback] = useState<Feedback[]>([]); const [error, setError] = useState("");
  useEffect(() => { const since = new Date(Date.now() - Number(range) * 86400000).toISOString(); const db = getSupabase(); if (!db) return;
    void Promise.all([db.from("meals").select("id,meal_name,service_at,prepared_portions,served_portions,leftover_portions,simulated").gte("service_at", since).order("service_at"), db.from("feedback").select("rating,simulated,created_at").gte("created_at", since)]).then(([m, f]) => { setMeals(m.data || []); setFeedback(f.data || []); setError(m.error?.message || f.error?.message || ""); });
  }, [range]);
  const selectedMeals = meals.filter(row => includeSimulated || !row.simulated); const selectedFeedback = feedback.filter(row => includeSimulated || !row.simulated);
  const totalPrepared = selectedMeals.reduce((sum, row) => sum + row.prepared_portions, 0); const totalLeft = selectedMeals.reduce((sum, row) => sum + row.leftover_portions, 0);
  const avg = selectedFeedback.length ? (selectedFeedback.reduce((sum, row) => sum + row.rating, 0) / selectedFeedback.length).toFixed(1) : "—";
  const max = Math.max(1, ...selectedMeals.map(row => row.prepared_portions));
  return <AppShell role="provider"><div className="page"><div className="page-heading"><p className="eyebrow">SERVICE TRENDS</p><h1>Analytics</h1><p className="muted">A short, transparent view of real service records.</p></div><div className="inline-heading"><label>Period <select className="input filter-select" value={range} onChange={e => setRange(e.target.value)}>{ANALYTICS_RANGES.map(days => <option key={days} value={days}>Last {days} days</option>)}</select></label><label className="checkbox-label"><input type="checkbox" checked={includeSimulated} onChange={e => setIncludeSimulated(e.target.checked)} /> Include simulated data</label></div>{error && <p className="error-text">{error}</p>}<div className="metric-grid"><Card><span className="muted">Services</span><strong className="metric-value">{selectedMeals.length}</strong></Card><Card><span className="muted">Prepared</span><strong className="metric-value">{totalPrepared}</strong></Card><Card><span className="muted">Leftover rate</span><strong className="metric-value">{totalPrepared ? `${Math.round(totalLeft / totalPrepared * 100)}%` : "—"}</strong></Card><Card><span className="muted">Average rating</span><strong className="metric-value">{avg}</strong></Card></div><Card><h2>Prepared vs served</h2>{selectedMeals.length === 0 ? <EmptyState>No service records in this period.</EmptyState> : <div className="chart-list">{selectedMeals.map(row => <div className="chart-row" key={row.id}><span>{new Date(row.service_at).toLocaleDateString()}</span><div className="chart-track"><i style={{ width: `${row.prepared_portions / max * 100}%` }} /><b style={{ width: `${row.served_portions / max * 100}%` }} /></div><span>{row.served_portions}/{row.prepared_portions}</span></div>)}</div>}<p className="chart-legend"><span/> Cobalt: prepared · Light blue: served</p></Card><ForecastVsActualChart /></div></AppShell>;
}
