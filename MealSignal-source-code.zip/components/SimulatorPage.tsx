// Lets providers add or clear labeled sample meal history for demonstrations.
"use client";
import { useState } from "react";
import { AppShell } from "./AppShell";
import { apiFetch } from "../lib/api";
import { Button, Card } from "./ui";

export function SimulatorPage() {
  const [message, setMessage] = useState(""); const [busy, setBusy] = useState(false);
  async function run(action: "last14days" | "clear") { if (action === "clear" && !window.confirm("Remove all simulated meals and their sample feedback?")) return; setBusy(true); setMessage("");
    const response = action === "clear" ? await apiFetch("/api/simulate", { method: "DELETE" }) : await apiFetch("/api/simulate", { method: "POST", body: JSON.stringify({ action }) });
    const result = await response.json(); setMessage(response.ok ? action === "clear" ? "Simulated records cleared." : `Created ${result.created} sample services. Refresh dashboard and analytics.` : result.error); setBusy(false);
  }
  return <AppShell role="provider"><div className="page"><div className="page-heading"><p className="eyebrow">DEMO DATA</p><h1>Simulator</h1><p className="muted">Create clearly labeled records so the project can be demonstrated without real diners.</p></div><Card><h2>Build a sample history</h2><p>This creates 14 days of past breakfast, lunch and dinner services, with sample reservations and anonymous comments. The records are marked simulated and can be cleared here.</p><div className="actions"><Button disabled={busy} onClick={() => void run("last14days")}>{busy ? "Working…" : "Simulate last 14 days"}</Button><Button className="button-danger" disabled={busy} onClick={() => void run("clear")}>Clear simulated data</Button></div>{message && <p role="status" className="notice">{message}</p>}</Card></div></AppShell>;
}
