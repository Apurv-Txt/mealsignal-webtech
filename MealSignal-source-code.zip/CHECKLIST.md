# MealSignal completion checklist

This checklist records the implementation state and the actions that still require a configured Supabase project or a browser on the user's laptop.

## PHASE 0 — Environment and AI key
- [x] Added safe environment checker and optional AI connection command.
- [x] AI key is read from server-only environment variables.
- [ ] Run `npm run test:ai-key` with a real key.

## PHASE 1 — Structure, theme and app shell
- [x] Split role-aware pages and navigation into obvious files.
- [x] Added mobile bottom navigation and readable black/cobalt theme.
- [x] Added one Supabase client and bearer-token helper.
- [ ] Tailwind is not installed; current styling uses one small global CSS file to avoid another dependency.
- [ ] Browser checks at 375px, 768px and 1280px.

## PHASE 2 — Login and sign-up
- [x] Added provider/diner sign-up and sign-in on `/login`.
- [x] Added join-code validation and role-aware landing paths.
- [ ] Verify both roles against a live Supabase project.

## PHASE 3 — Database v2 and seed
- [x] Added re-runnable v2 migration, aggregate view and seed SQL.
- [x] Removed client-readable diner IDs from feedback and reservation selects.
- [ ] Run both migrations and seed in Supabase SQL Editor; SQL execution is not available here.

## PHASE 4 — Provider meal planning
- [x] Added add/edit/delete, dishes, date/time and expected portions.
- [ ] Verify persistence and delete confirmation against Supabase.

## PHASE 5 — Diner portal
- [x] Added individual meal reservations, skip, and per-dish rating/edit flows.
- [x] Added own reservation and rating history sections.
- [ ] Verify cross-account access and post-service rating rules in Supabase.

## PHASE 6 — Provider dashboard and service log
- [x] Dashboard totals come from the database and show empty values when there is no data.
- [x] Portion logging checks counts and updates the selected meal.
- [ ] Verify totals against live SQL queries.

## PHASE 7 — Provider feedback
- [x] Added anonymous comments, filters, rating summary, CSV export and on-demand insight panel.
- [ ] Confirm CSV and feedback access with a provider account.

## PHASE 8 — Analytics
- [x] Added 7/14/30-day summaries, simulated-data filter and forecast error comparison.
- [ ] Validate chart values against seeded service records.

## PHASE 9 — Diner simulator
- [x] Added protected simulator for 14 days of services, reservations and feedback.
- [x] Simulated records can be cleared and are labeled in feedback.
- [ ] Run against Supabase after v2 migration.

## PHASE 10 — AI feedback insights
- [x] Endpoint reads bounded feedback from the signed-in provider's workspace only.
- [x] Added local fallback and evidence checks.
- [ ] Check live AI and local modes.

## PHASE 11 — Demand forecast and backtest
- [x] Forecast uses current reservations and same-service historical walk-ins.
- [x] Added MAE/MAPE and previous-service baseline.
- [ ] Check numerical results against a populated Supabase workspace.

## PHASE 12 — Polish and deployment preparation
- [x] Removed inactive navigation actions and added error/404 screens.
- [x] API routes require signed-in provider access where appropriate.
- [ ] Webpack compilation and TypeScript passed during `npm run build`, but static page generation failed with Windows `EPERM` creating a nested `.next/server/app/feedback.segments/feedback` directory. The Google Fonts fetch was removed; rerun `npm run build` on the laptop.
- [ ] Verify keyboard focus and responsive layouts in a browser.
- [ ] Deploy to Vercel and configure Supabase redirect URLs.

## PHASE 13 — README, report and viva notes
- [x] Rewrote setup documentation and created report, screenshots checklist and explanation notes.
- [ ] Capture actual screenshots, add teammate names, confirm actual contribution split, and add GitHub/live URLs.

## Decisions

- No demo numbers are rendered by the dashboard. Use the explicit simulator or SQL seed for realistic sample data.
- No production build or database integration is claimed until checked on the laptop with network access and Supabase credentials.
- CSS variables are used instead of Tailwind so the dark palette and responsive rules remain in one short file without another package.
