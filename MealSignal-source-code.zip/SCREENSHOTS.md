# Screenshot checklist

Capture from the final running app after applying both migrations and loading sample records. Use demo accounts and avoid showing email addresses or other personal data.

- [ ] `/login` — sign-in card
- [ ] `/login` — provider sign-up fields
- [ ] `/login` — diner sign-up with join code
- [ ] `/diner` — upcoming meal menu
- [ ] `/diner` — a meal reserved and another skipped
- [ ] `/diner#my-reservations` — reservation history
- [ ] `/diner` — rating form after a meal is marked Served
- [ ] `/diner#my-ratings` — saved rating history
- [ ] `/dashboard` — provider metrics and service list
- [ ] `/dashboard` — service log saved with prepared, served and leftover counts
- [ ] `/meals` — meal form with dishes and date/time
- [ ] `/meals` — upcoming and past meal filters
- [ ] `/feedback` — anonymous comments and filters
- [ ] `/feedback` — Local insights mode without an AI key
- [ ] `/feedback` — AI insights mode when configured
- [ ] `/analytics` — date range, simulated-data toggle and service chart
- [ ] `/analytics` — forecast vs actual with MAE/MAPE
- [ ] `/simulator` — sample history created and simulated labels visible
- [ ] Mobile width 375px — diner menu and bottom navigation
- [ ] Mobile width 375px — provider dashboard and meal form

Save final images under `public/report/` and update the screenshot table in `REPORT.md` to embed those files.
