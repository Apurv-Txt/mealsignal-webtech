// Sign in or create a provider or diner account.
import { LoginForm } from "../../components/LoginForm";
export default function LoginPage() { return <LoginForm />; }
