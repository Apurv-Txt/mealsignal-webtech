// Keeps the old account URL working while the login page has a single route.
import { redirect } from "next/navigation";
export default function AccountPage() { redirect("/login"); }
