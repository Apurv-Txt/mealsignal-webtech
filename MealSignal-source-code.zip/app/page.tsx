// Sends visitors to the appropriate workspace entry point.
import { redirect } from "next/navigation";
export default function Home() { redirect("/dashboard"); }
