// Gives visitors a useful way back from an unknown URL.
import Link from "next/link";
export default function NotFound() { return <main className="center-page"><h1>Page not found</h1><p>The address may have changed.</p><Link href="/dashboard">Back to MealSignal</Link></main>; }
