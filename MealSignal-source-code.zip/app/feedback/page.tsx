// Provider feedback and insight page.
import { FeedbackPage } from "../../components/FeedbackPage";
export default function Page() { return <FeedbackPage />; }
