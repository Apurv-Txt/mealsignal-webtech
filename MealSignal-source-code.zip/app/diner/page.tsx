// Diner menu, reservation and ratings route.
import { DinerPage } from "../../components/DinerPage";
export default function Page() { return <DinerPage />; }
