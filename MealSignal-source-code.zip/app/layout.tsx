import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "MealSignal — meal service, in sync", description: "Plan portions with reservations, service records and diner feedback." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
