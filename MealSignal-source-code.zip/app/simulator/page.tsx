// Provider-only sample data simulator.
import { SimulatorPage } from "../../components/SimulatorPage";
export default function Page() { return <SimulatorPage />; }
