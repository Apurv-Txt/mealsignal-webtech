// Shows a plain recovery option when a page fails to render.
"use client";
export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <main className="center-page"><h1>That page could not load.</h1><p>Try again in a moment.</p><button className="button" onClick={() => reset()}>Try again</button></main>;
}
