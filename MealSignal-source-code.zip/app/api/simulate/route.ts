// Creates or clears clearly marked sample records for a provider demo.
import { NextResponse } from "next/server";
import { getCaller } from "../../../lib/server-auth";
import { SIM_COMMENTS } from "../../../lib/sim-comments";
import { SERVICE_TYPES, SIMULATED_FEEDBACK_PER_MEAL, SIMULATED_HISTORY_DAYS, SIMULATED_PORTIONS, SIMULATED_RESERVATION_RATE } from "../../../lib/constants";

export async function POST(request: Request) {
  const caller = await getCaller(request);
  if (!caller) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (caller.profile.role !== "provider") return NextResponse.json({ error: "Provider account required." }, { status: 403 });
  const body = await request.json().catch(() => ({}));
  if (body.action !== "last14days") return NextResponse.json({ error: "Unknown simulation action." }, { status: 400 });
  const meals = [];
  for (let offset = -SIMULATED_HISTORY_DAYS; offset < 0; offset++) for (const type of SERVICE_TYPES.slice(0, 3)) {
    const date = new Date(); date.setDate(date.getDate() + offset); date.setHours(type === "Breakfast" ? 8 : type === "Lunch" ? 12 : 19, 0, 0, 0);
    meals.push({ organization_id: caller.profile.organization_id, meal_name: `${type} sample service`, service_type: type, service_at: date.toISOString(), dishes: type === "Breakfast" ? ["Idli", "Sambar"] : type === "Lunch" ? ["Rice", "Dal", "Vegetables"] : ["Roti", "Curry", "Salad"], expected_portions: SIMULATED_PORTIONS, prepared_portions: SIMULATED_PORTIONS, served_portions: 72 + Math.floor(Math.random() * 16), leftover_portions: 0, status: "Served", simulated: true });
  }
  for (const meal of meals) meal.leftover_portions = Math.max(0, meal.prepared_portions - meal.served_portions);
  const { data, error } = await caller.db.from("meals").insert(meals).select("id,dishes,served_portions");
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  const sampleMeals = data || [];
  const reservations = sampleMeals.flatMap(meal => Array.from({ length: Math.floor(meal.served_portions * SIMULATED_RESERVATION_RATE) }, () => ({ meal_id: meal.id, diner_id: null, status: "reserved", simulated: true })));
  const feedback = sampleMeals.flatMap(meal => Array.from({ length: SIMULATED_FEEDBACK_PER_MEAL }, (_, index) => ({ meal_id: meal.id, diner_id: null, dish: meal.dishes?.[index % meal.dishes.length] || "Meal", rating: 3 + Math.floor(Math.random() * 3), comment: SIM_COMMENTS[Math.floor(Math.random() * SIM_COMMENTS.length)], simulated: true })));
  const reservationWrite = await caller.db.from("reservations").insert(reservations);
  const feedbackWrite = await caller.db.from("feedback").insert(feedback);
  if (reservationWrite.error || feedbackWrite.error) {
    await caller.db.from("meals").delete().in("id", sampleMeals.map(meal => meal.id));
    return NextResponse.json({ error: reservationWrite.error?.message || feedbackWrite.error?.message }, { status: 400 });
  }
  return NextResponse.json({ created: sampleMeals.length });
}

export async function DELETE(request: Request) {
  const caller = await getCaller(request);
  if (!caller) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (caller.profile.role !== "provider") return NextResponse.json({ error: "Provider account required." }, { status: 403 });
  const { error } = await caller.db.from("meals").delete().eq("organization_id", caller.profile.organization_id).eq("simulated", true);
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ cleared: true });
}
