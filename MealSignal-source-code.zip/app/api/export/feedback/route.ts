// Exports only the signed-in provider's filtered organization feedback.
import { NextResponse } from "next/server";
import { getCaller } from "../../../../lib/server-auth";
import { FEEDBACK_EXPORT_LIMIT } from "../../../../lib/constants";

export async function GET(request: Request) {
  const caller = await getCaller(request);
  if (!caller) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (caller.profile.role !== "provider") return NextResponse.json({ error: "Provider account required." }, { status: 403 });
  const params = new URL(request.url).searchParams; const search = params.get("search")?.slice(0, 80) || "";
  const rating = Number(params.get("rating"));
  const { data, error } = await caller.db.from("feedback").select("dish,rating,comment,created_at,simulated").order("created_at", { ascending: false }).limit(FEEDBACK_EXPORT_LIMIT);
  if (error) return NextResponse.json({ error: "Could not export feedback." }, { status: 500 });
  const filtered = (data || []).filter(row => (!(rating >= 1 && rating <= 5) || row.rating === rating) && (!search || `${row.dish} ${row.comment}`.toLowerCase().includes(search.toLowerCase())));
  const rows = [["Dish", "Rating", "Comment", "Date", "Simulated"], ...filtered.map(row => [row.dish, String(row.rating), row.comment, row.created_at, row.simulated ? "Yes" : "No"] as string[])];
  const csv = rows.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\r\n");
  return new Response(csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": "attachment; filename=mealsignal-feedback.csv" } });
}
