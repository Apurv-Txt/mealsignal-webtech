// Calculates an explainable demand estimate from same-service history.
import { NextResponse } from "next/server";
import { getCaller } from "../../../lib/server-auth";
import { FORECAST_HISTORY_LIMIT, FORECAST_MIN_CONFIDENCE_SERVICES } from "../../../lib/constants";

export async function GET(request: Request) {
  const caller = await getCaller(request);
  if (!caller) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (caller.profile.role !== "provider") return NextResponse.json({ error: "Provider account required." }, { status: 403 });
  const mealId = new URL(request.url).searchParams.get("mealId");
  if (!mealId) return NextResponse.json({ error: "Choose a meal." }, { status: 400 });
  const { data: meal } = await caller.db.from("meals").select("id,service_type,service_at").eq("id", mealId).single();
  if (!meal) return NextResponse.json({ error: "Meal not found." }, { status: 404 });
  const { count: reservations } = await caller.db.from("reservations").select("id", { count: "exact", head: true }).eq("meal_id", mealId).eq("status", "reserved");
  const { data: history } = await caller.db.from("meals").select("id,served_portions").eq("service_type", meal.service_type).eq("status", "Served").lt("service_at", meal.service_at).order("service_at", { ascending: false }).limit(FORECAST_HISTORY_LIMIT);
  const historyIds = (history || []).map(row => row.id);
  const { data: pastReservations } = historyIds.length ? await caller.db.from("reservations").select("meal_id,status").in("meal_id", historyIds) : { data: [] };
  const walkIns = (history || []).map(row => Math.max(0, row.served_portions - (pastReservations || []).filter(reservation => reservation.meal_id === row.id && reservation.status === "reserved").length));
  const average = walkIns.length ? walkIns.reduce((sum, n) => sum + n, 0) / walkIns.length : 0;
  const low = walkIns.length ? Math.min(...walkIns) : 0; const high = walkIns.length ? Math.max(...walkIns) : 0;
  const coverage = Number(reservations || 0); const total = coverage + Math.round(average);
  let confidence = "Learning";
  if (walkIns.length >= FORECAST_MIN_CONFIDENCE_SERVICES) confidence = high - low <= Math.max(5, average * 0.4) ? "Steady" : "Variable";
  return NextResponse.json({ total, low: coverage + low, high: coverage + high, reservations: coverage, walkIns: Math.round(average), confidence, historyCount: walkIns.length, explanation: `Based on ${coverage} reservations and ${walkIns.length} earlier ${meal.service_type.toLowerCase()} services.` });
}
