// Compares historical forecasts with a simple previous-service baseline.
import { NextResponse } from "next/server";
import { getCaller } from "../../../../lib/server-auth";
import { FORECAST_BACKTEST_MAX_DAYS, FORECAST_HISTORY_LIMIT } from "../../../../lib/constants";

export async function GET(request: Request) {
  const caller = await getCaller(request);
  if (!caller) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (caller.profile.role !== "provider") return NextResponse.json({ error: "Provider account required." }, { status: 403 });
  const days = Math.min(FORECAST_BACKTEST_MAX_DAYS, Math.max(7, Number(new URL(request.url).searchParams.get("days")) || FORECAST_BACKTEST_MAX_DAYS));
  const { data: meals } = await caller.db.from("meals").select("id,service_type,service_at,served_portions").eq("status", "Served").gte("service_at", new Date(Date.now() - days * 86400000).toISOString()).order("service_at");
  if (!meals?.length) return NextResponse.json({ series: [], mae: null, mape: null, baselineMae: null });
  const ids = meals.map(meal => meal.id); const { data: reservations } = await caller.db.from("reservations").select("meal_id,status").in("meal_id", ids).eq("status", "reserved");
  const reserved = (id: string) => (reservations || []).filter(row => row.meal_id === id).length;
  const series = meals.map((meal, index) => {
    const earlier = meals.slice(0, index).filter(row => row.service_type === meal.service_type).slice(-FORECAST_HISTORY_LIMIT);
    const meanWalkIns = earlier.length ? earlier.reduce((sum, row) => sum + Math.max(0, row.served_portions - reserved(row.id)), 0) / earlier.length : 0;
    return { date: meal.service_at, serviceType: meal.service_type, forecast: reserved(meal.id) + Math.round(meanWalkIns), actual: meal.served_portions, baseline: earlier.length ? earlier[earlier.length - 1].served_portions : null };
  });
  const mae = (items: typeof series) => items.length ? Number((items.reduce((sum, row) => sum + Math.abs(row.forecast - row.actual), 0) / items.length).toFixed(1)) : null;
  const mapeRows = series.filter(row => row.actual > 0);
  const baselineRows = series.filter(row => row.baseline !== null);
  return NextResponse.json({ series, mae: mae(series), mape: mapeRows.length ? Number((mapeRows.reduce((sum, row) => sum + Math.abs(row.forecast - row.actual) / row.actual, 0) / mapeRows.length * 100).toFixed(1)) : null, baselineMae: baselineRows.length ? Number((baselineRows.reduce((sum, row) => sum + Math.abs((row.baseline || 0) - row.actual), 0) / baselineRows.length).toFixed(1)) : null });
}
