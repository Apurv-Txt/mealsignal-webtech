// Provider meal planning page.
import { MealsPage } from "../../components/MealsPage";
export default function Page() { return <MealsPage />; }
